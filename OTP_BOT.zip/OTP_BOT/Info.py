#Twilio

account_sid = ''
auth_token = ''
twilionumber = ''
twiliosmsnumber = ''

#Telegram Bot Token
API_TOKEN = "" 

#Host URL
callurl = '' 
twiliosmsurl = ''









